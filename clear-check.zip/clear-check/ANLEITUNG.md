# Clear-Check einrichten (Netlify + Google Gemini)

Einmalig, etwa 20–30 Minuten. Die Menünamen können bei Google, GitHub und Netlify leicht abweichen.

## 1. Gemini-Schlüssel holen
1. https://aistudio.google.com öffnen und mit einem Google-Konto anmelden.
2. „Get API key“ bzw. „API-Schlüssel erstellen“ wählen und den Schlüssel kopieren.
3. Keine Zahlungsdaten hinterlegen, dann bleibt es bei der kostenlosen Stufe.
4. Den Schlüssel niemandem weitergeben.

## 2. Dateien auf GitHub hochladen
1. Auf https://github.com ein kostenloses Konto anlegen.
2. Oben rechts „+“ → „New repository“, Name z. B. `clear-check`, „Private“ ist möglich → „Create repository“.
3. Auf „uploading an existing file“ klicken.
4. Die ZIP-Datei entpacken und den **Inhalt** des Ordners `clear-check` (index.html, netlify.toml, ANLEITUNG.md und den Ordner `netlify`) in das Browserfenster ziehen.
5. Unten „Commit changes“ klicken.

## 3. Website bei Netlify anlegen
1. https://app.netlify.com öffnen und mit „Sign up with GitHub“ anmelden.
2. „Add new project“ → „Import an existing project“ → GitHub → das Repository `clear-check` auswählen.
3. Die Einstellungen so lassen und „Deploy“ klicken.

## 4. Schlüssel und Kurscode eintragen
1. Im Projekt: „Project configuration“ → „Environment variables“ → „Add a variable“.
2. `GEMINI_API_KEY` = dein Schlüssel aus Schritt 1.
3. `KURSCODE` = ein Code, den du dir ausdenkst (z. B. `clear24`) und dem Kurs nennst.
4. Danach unter „Deploys“ → „Trigger deploy“ → „Deploy project“. Erst nach diesem neuen Deploy sind die Werte aktiv.

## 5. Testen und teilen
1. Die Adresse (`…netlify.app`) öffnen, selbst ein Video durchlaufen lassen.
2. Optional: unter „Project configuration“ → „Change project name“ eine schönere Adresse wählen, z. B. `clear-check-rhs`.
3. Link und Kurscode an den Kurs geben.

## Wenn etwas nicht klappt
- **„Kurscode stimmt nicht“:** Groß-/Kleinschreibung ist egal; Wert in Netlify prüfen und neu deployen.
- **„Noch nicht fertig eingerichtet“:** `GEMINI_API_KEY` fehlt oder es wurde nach dem Eintragen nicht neu deployt.
- **„Schlüsselproblem“:** Schlüssel neu aus AI Studio kopieren und in Netlify ersetzen.
- **„Modell nicht gefunden“:** In Netlify eine Variable `GEMINI_MODEL` anlegen und den Namen eines aktuellen Flash-Modells aus AI Studio eintragen (z. B. so, wie er dort in der Modellauswahl steht).
- **„Sehr viele gleichzeitig“:** Das Gratis-Kontingent pro Minute ist erschöpft; eine Minute warten.

## Kurscode oder Texte später ändern
- Kurscode: in Netlify bei den Environment variables ändern und neu deployen.
- Die Knotenpunkte und der Auftrag an die KI stehen in `netlify/edge-functions/analyze.js`. Datei auf GitHub öffnen, mit dem Stift-Symbol bearbeiten, speichern; Netlify veröffentlicht automatisch neu.
